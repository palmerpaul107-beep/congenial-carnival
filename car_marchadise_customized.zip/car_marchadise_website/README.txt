CAR MARCHADISE WEBSITE — CUSTOMIZED SETUP

Your current settings:
- Business name: Car Marchadise
- Location: Nairobi, Kenya
- WhatsApp: +254 769 363 105 (configured)
- Inventory focus: Brand-new cars
- YouTube channel: Not provided yet

BEFORE PUBLISHING:
1. Open index.html in a browser to preview the website.
2. Replace the sample vehicle cards with your real brand-new stock: correct model, year, price in KSh, mileage/specifications and genuine photos.
3. Add your business email, exact showroom address and dealership story.
4. Add a YouTube video ID in the setup section near the bottom of index.html whenever you have a video.

PUBLISH FREE WITH GITHUB PAGES:
1. Create/sign in to GitHub: https://github.com
2. Create a new public repository named car-marchadise.
3. Upload index.html to the top/root of that repository (README.txt is optional).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Your website address will appear on that Pages screen, usually https://YOUR-USERNAME.github.io/car-marchadise/.
8. Open that address on your phone to test it.

ADD THE WEBSITE TO YOUTUBE:
1. Open https://studio.youtube.com/
2. Select Customization > Profile.
3. Under Links, add the published website address.
4. Save/publish your channel changes.
5. You can also add the website address to video descriptions.

NOTE:
The website is a static starter site. GitHub Pages hosts it; it does not automatically register a domain name. You can connect a custom domain later.
